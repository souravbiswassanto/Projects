
	<style type="text/css">
		*{
			margin:0;
			padding: 0;
		}
		.mainfooter{
			
		}
		.footerdiv{
			width:100%;
			background-color: #353535;
		}
		.footertable{
			padding-top:30px;
			padding-bottom: 30px;
			width:80%;
		}
		.footertable th{
			color:white;
			font-size: 20px;
			font-family: Muli, sans-serif;
			padding-bottom: 40px;
		}
		.footertable td{
			font-family: Muli, sans-serif;
			text-align: center;
			padding-bottom: 10px;
		}
		.footertable a{
			color:white;
			opacity: 0.7;
			text-decoration: none;
		}
		.footertable a:hover{
			color:#00BCD4;
		}
		#contactinfo{
			color:white;
			opacity: 0.7;
		}
	</style>
	<center class="mainfooter">
		<footer>
			<div class="footerdiv">
				<table class="footertable">
					<tr>
						<th>More Details</th>
						<th>Menu</th>
						<th>Contact info</th>
					</tr>
					<tr>
						<td><a href="about.php">About us</a></td>
						<td><a href="details.php">Buy Books</a></td>
						<td id="contactinfo"><img src="images/location.png" height="20" width="20">University of Barisal,Barisal</td>
					</tr>
					<tr>
						<td><a href="conditions.php">Tearms and conditions</a></td>
						<td><a href="postadd.php">Sell Books</a></td>
						<td id="contactinfo">+8801783311066</td>
					</tr>
					<tr>
						<td><a href="howtosellfast.php">How to sell fast?</a></td>
						<td></td>
						<td id="contactinfo">buwalkineds@gmail.com</td>
					</tr>
				</table>
				<p style="padding-bottom: 20px; color:white; opacity: 0.7;">All rights reserved</p>
			</div>
		</footer>
	</center>
</body>
</html>