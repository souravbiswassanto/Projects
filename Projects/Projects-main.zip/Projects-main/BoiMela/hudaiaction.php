<?php 

	$L=$_GET['location'];

	echo $L;
 ?>